package fflames.gui.forms;

import fflames.base.FractalGenerator;
import fflames.base.IColoring;
import fflames.base.Transform;
import fflames.base.coloring.ColoringFactory;
import fflames.gui.ExportXMLFileFractal;
import fflames.gui.ImportXMLFractalFile;
import fflames.gui.MainWindowActions;
import fflames.gui.events.LoadProject;
import fflames.gui.exceptions.ImportXMLFractalFileException;
import fflames.gui.model.AffineTransformModel;
import fflames.gui.model.AlgorithmConfigurationModel;
import fflames.gui.model.ApplicationState;
import fflames.gui.model.ProgressModel;
import fflames.gui.model.RecentOpenedModel;
import fflames.gui.model.RenderedImageModel;
import fflames.gui.model.TransformTableModel;
import fflames.gui.model.VariationsTableModel;
import fflames.gui.ui.BasicMainWindowUI;
import fflames.gui.ui.MainWindowUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import javax.imageio.ImageIO;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import prefs.Settings;

/**
 * Application main window component
 * 
 * @author Pawel Korus
 */
public class MainWindow extends JComponent implements ActionListener {
	/**
	 * The UI class ID string
	 */
	private static final String uiClassID = "FFlamesMainWidnowUI";
	
	public MainWindow() {
		super();
		
		_state = new ApplicationState();
		
		_transformsModel = new TransformTableModel();
		
		_recentOpenedModel = 
				new RecentOpenedModel(
						Settings.getInstance().getRecentOpenedPaths(), 10);
		
		_affineTransformModel = new AffineTransformModel();
		
		_variationsTableModel = new VariationsTableModel();
		
		_algorithmConfigurationModel = new AlgorithmConfigurationModel();
		
		_progressModel = new ProgressModel();
		
		_renderedImageModel = new RenderedImageModel();
		
		_threadPool = Executors.newFixedThreadPool(6);
		
		updateUI();
	}
	
	public void setUI(MainWindowUI ui) {
		super.setUI(ui);
	}
	
	@Override
	public void updateUI() {
		if (UIManager.get(getUIClassID()) != null) {
			setUI((MainWindowUI) UIManager.getUI(this));
		} else {
			setUI(new BasicMainWindowUI());
		}
	}
	
	public MainWindowUI getUI() {
		return (MainWindowUI) ui;
	}
	
	@Override
	public String getUIClassID() {
		return uiClassID;
	}
	
	public void loadFractalFile(String filePath) {
		reset();
		
		ArrayList<Transform> transforms = new ArrayList<>();
		ImportXMLFractalFile importer = new ImportXMLFractalFile();
		
		try {
			importer.load(transforms, filePath);
			
			transforms.stream().forEach((t) -> {
				_transformsModel.add(t);
			});
			
			_state.setParam(ApplicationState.LOADED_FRACTAL_FILE_PATH, filePath);
			_recentOpenedModel.add(filePath);
		
		} catch (ImportXMLFractalFileException exception) {
			JOptionPane.showMessageDialog(this, "Error occured when parsing choosen file", "Import error", JOptionPane.ERROR_MESSAGE);
			exception.printStackTrace();
		} catch (IOException exception) {
			JOptionPane.showMessageDialog(this, "Error when reading from choosen file", "Import error", JOptionPane.ERROR_MESSAGE);
			exception.printStackTrace();
		}
	}
	
	public void saveFractalFile() {
		if(_state.isFractalFileLoaded()) {
			saveFractalFile(_state.getLoadedFractalFilePath());
		}
	}
	
	public void saveFractalFile(String filePath) {
		ExportXMLFileFractal exporter = new ExportXMLFileFractal(_transformsModel.getTransforms());
		
		try {
			exporter.save(filePath);
		} catch (IOException exception) {
			JOptionPane.showMessageDialog(this, "Error when exporting to choosen file", "Export error", JOptionPane.ERROR_MESSAGE);
			exception.printStackTrace();
		}
	}
	
	public void saveImageFile(File file) {
		try {
			ImageIO.write((RenderedImage) _renderedImageModel.getImage(), "png", file);
		} catch (IOException exception) {
			JOptionPane.showMessageDialog(this, "Error when saving image file", "Export error", JOptionPane.ERROR_MESSAGE);
			exception.printStackTrace();
		}
	}
	
	public void drawFractal() {
		if(_transformsModel.getRowCount() > 0) {
			MainWindow.DrawingWorker task = new MainWindow.DrawingWorker();
			task.execute();
		}
	}
	
	public void addTransform() {
		Double propability = getUI().getFunctionPropability();
		_transformsModel.addNew(_affineTransformModel.getTransform(), _variationsTableModel.getVariations(), propability);
	}
	
	public void removeTransform(int index) {
		_transformsModel.remove(index);
	}
	
	public void newFractal() {
		reset();
	}
	
	public void reset() {
		_transformsModel.reset();
		/** @todo I think in gui we need to wait for events and clear selection */
		//_view.getTranformsList().clearSelection();
		
		_affineTransformModel.reset();
		
		_variationsTableModel.reset();
		
		_state.setParam(ApplicationState.LOADED_FRACTAL_FILE_PATH, "");
		
		_progressModel.reset();
	}
	
	public void exit() {
		try {
			_threadPool.shutdown();
			_threadPool.awaitTermination(2, TimeUnit.SECONDS);
		} catch(InterruptedException e) {

		} finally {
			if(!_threadPool.isTerminated()) {
				_threadPool.shutdownNow();
			}
		}
	}
	
	public void setCurrentTransform(int index) {
		double propability = (Double) _transformsModel.getValueAt(index, 0);
		
		getUI().setFunctionPropability(propability);
		
		AffineTransform transform = 
				(AffineTransform) _transformsModel.getAffineTransformAt(index);
		_affineTransformModel.setTransform(transform);
				
		_variationsTableModel
				.setVariations(_transformsModel.getVariationsAt(index));
	}
	
	public TransformTableModel getTransformsModel() {
		return _transformsModel;
	}
	
	public RecentOpenedModel getRecentOpenedModel() {
		return _recentOpenedModel;
	}
	
	public AffineTransformModel getAffineTransfomModel() {
		return _affineTransformModel;
	}
	
	public AlgorithmConfigurationModel getAlgorithmConfigurationModel() {
		return _algorithmConfigurationModel;
	}
	
	public ProgressModel getProgressModel() {
		return _progressModel;
	}
	
	public RenderedImageModel getRenderedImageModel() {
		return _renderedImageModel;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		int id = e.getID();

		if(fflames.gui.events.Action.Actions.NewProject.equals(id)) {
			newFractal();
		} else if(fflames.gui.events.Action.Actions.AddTransform.equals(id)) {
			addTransform();
		} else if(fflames.gui.events.Action.Actions.RemoveTransform.equals(id)) {
			//int index = _transformsList.getSelectedRow();
			int index = 0;
			removeTransform(index);
		} else if(fflames.gui.events.Action.Actions.LoadProject.equals(id)) {
			LoadProject evt = (LoadProject) e;
			String filePath = evt.getFilePath();

			if(filePath.isEmpty()) {
				JFileChooser fileChooser = new JFileChooser();
				fileChooser.setApproveButtonText("Open");
				fileChooser.setCurrentDirectory(null);
				fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("XML files", "xml"));
				int returnValue = fileChooser.showOpenDialog(this);
				if(returnValue == JFileChooser.APPROVE_OPTION) {
					filePath = fileChooser.getSelectedFile().getAbsolutePath();
				} else {
					return;
				}
			}

			loadFractalFile(filePath);
		} else if(fflames.gui.events.Action.Actions.SaveProject.equals(id)) {
			JFileChooser fileChooser = new JFileChooser();
			fileChooser.setApproveButtonText("Save");
			fileChooser.setCurrentDirectory(null);
			fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("XML files", "xml"));
			int returnValue = fileChooser.showSaveDialog(this);
			if(returnValue == JFileChooser.APPROVE_OPTION) {
				saveFractalFile(fileChooser.getSelectedFile().getAbsolutePath());
			} else {
				return;
			}
		} else if(fflames.gui.events.Action.Actions.SaveGeneratedImage.equals(id)) {
			JFileChooser fileChooser = new JFileChooser();
			fileChooser.setApproveButtonText("Save");
			fileChooser.setCurrentDirectory(null);
			fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("PNG files", "png"));
			int returnValue = fileChooser.showSaveDialog(this);
			if(returnValue == JFileChooser.APPROVE_OPTION) {
				saveImageFile(fileChooser.getSelectedFile());
			} else {
				return;
			}
		} else if(fflames.gui.events.Action.Actions.ExitApplication.equals(id)) {
			throw new UnsupportedOperationException();
		} else if(fflames.gui.events.Action.Actions.Draw.equals(id)) {
			drawFractal();
		} else if(fflames.gui.events.Action.Actions.ShowAbout.equals(id)) {
			JDialog dialog = new AboutDialog();
			dialog.setVisible(true);
		}
	}
	
	private class DrawingWorker extends SwingWorker<BufferedImage, Integer> {

		@Override
		protected BufferedImage doInBackground() {	
			/*ColoringFactory colorsFactory = new ColoringFactory();
			
			IColoring coloringMethod = colorsFactory.getColoring(_view.getColoringEditor().getSelectedIndex(), _view.getColoringEditor().getSelectedColors()); 
			
			int[] size = { 
				_algorithmConfigurationModel.getImageWidth(),
				_algorithmConfigurationModel.getImageHeight()
			};
			
			FractalGenerator fractalGenerator = new FractalGenerator(
					_transformsModel.getTransforms(), 
					coloringMethod,
					size,
					_algorithmConfigurationModel.getIterationsNumber(),
					_algorithmConfigurationModel.getSuperSampling(),
					_algorithmConfigurationModel.getRotationsNumber(),
					_threadPool);
			
			long startTime = System.nanoTime();

			int p = 0;
			BufferedImage out = new BufferedImage(1, 1, 1);
			
			_progressModel.setStartProgressValue(1);
			_progressModel.setEndProgressValue(_algorithmConfigurationModel.getIterationsNumber());
			_progressModel.reset();
			
			try {
				Future<BufferedImage> f = fractalGenerator.execute();
				while(!f.isDone()) {
					try {
						f.get(10, TimeUnit.MILLISECONDS);
					} catch(TimeoutException e) {
						_progressModel.setProgress(fractalGenerator.getProgress());
					}
				}
				_progressModel.setProgress(100);
				out = f.get();
			} catch(InterruptedException | ExecutionException e) {

			}
			
			long endTime = System.nanoTime();
			long duration = (endTime - startTime)/1000000; // miliseconds
			System.out.println("Generator execution time: " + duration );
						
			return out;*/
			return new BufferedImage(10, 10, 1);
		}
		
		@Override
		protected void done() { 
			// this method is executed on the Dispatch Event thread
			try {
				BufferedImage result = get();
			
				_renderedImageModel.setImage(result);
			} catch(InterruptedException | ExecutionException e) {
				
			}
		}	
	}
	
	private TransformTableModel _transformsModel;
	private RecentOpenedModel _recentOpenedModel;
	private ApplicationState _state;
	private AffineTransformModel _affineTransformModel;
	private VariationsTableModel _variationsTableModel;
	private AlgorithmConfigurationModel _algorithmConfigurationModel;
	private ProgressModel _progressModel;
	private RenderedImageModel _renderedImageModel;
	private ExecutorService _threadPool;
}
