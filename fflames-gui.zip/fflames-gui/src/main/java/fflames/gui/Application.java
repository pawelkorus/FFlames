package fflames.gui;

import fflames.gui.forms.MainWindow;
import fflames.gui.model.AlgorithmConfigurationModel;
import fflames.gui.model.ApplicationState;
import fflames.gui.model.TransformTableModel;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JSeparator;
import javax.swing.UIManager;

public final class Application implements Runnable {

	public Application() {
		
	}

	@Override
	public void run() {
		UIManager.getDefaults().put("FFlamesMainWidnowUI", "fflames.gui.ui.BasicMainWindowUI");
		
		_mainFrame = new JFrame();
		
		_mainFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		//frame.setTitle(_state.getApplicationName());
		_mainFrame.setMinimumSize(new java.awt.Dimension(800, 600));
		_mainFrame.setName("mainFrame"); // NOI18N
		
		_actions = new MainWindowActions(_mainFrame);

		_menuBar = new JMenuBar();
		_mainFrame.setJMenuBar(_menuBar);

		_mnFile = new JMenu("File");
		_menuBar.add(_mnFile);

		_mnFile.add(_actions.createNewFractalAction());

		JSeparator separator = new JSeparator();
		_mnFile.add(separator);

		_mnFile.add(_actions.createOpenAction(""));

		_mnOpenRecent = new JMenu("Open recent");
		_mnFile.add(_mnOpenRecent);

		JSeparator separator_1 = new JSeparator();
		_mnFile.add(separator_1);

		_mnFile.add(_actions.createSaveAction());

		_mnFile.add(_actions.createSaveImageAction());

		JSeparator separator_2 = new JSeparator();
		_mnFile.add(separator_2);

		_mnFile.add(_actions.createExitAction());

		_mnAbout = new JMenu("About");
		_menuBar.add(_mnAbout);

		_mnAbout.add(_actions.createShowAboutAction());
		
		_mainWindow = new MainWindow();
		
		_mainFrame.add(_mainWindow);
		
		_mainFrame.setVisible(true);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		java.awt.EventQueue.invokeLater(new Application());
	}
	
	//private MyFractals _mainWindow;
	private MainWindow _mainWindow;
	private JFrame _mainFrame;
	private JMenuBar _menuBar;
	private JMenu _mnFile;
	private JMenu _mnOpenRecent;
	private JMenu _mnAbout;
	private MainWindowActions _actions;
}
